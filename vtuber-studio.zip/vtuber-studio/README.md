# VTuber Studio (Android)

App para animar un personaje 2D con la cámara frontal y armarlo importando tus propias imágenes. Todo se procesa en el teléfono.

## Cómo conseguir el APK

### Opción A: sin instalar nada (GitHub Actions)
1. Crea un repositorio en GitHub y sube **el contenido de esta carpeta** (incluida la carpeta oculta `.github`).
2. Entra en la pestaña **Actions** → **Compilar APK** → **Run workflow** (también corre solo en cada subida).
3. Cuando termine (unos 5–10 min), abre la ejecución y descarga **VTuber-Studio-APK** al final de la página. Dentro está `app-debug.apk`.
4. Pásalo al teléfono, ábrelo y permite "instalar apps de orígenes desconocidos" si te lo pide.

### Opción B: en tu PC con Android Studio
Necesitas Node 20+, Android Studio (con su SDK) y JDK 21.
```
npm install
npm run prepare:web
npm run android:add
npx cap sync android
npx cap open android      # en Android Studio: Build > Build APK(s)
```
El APK queda en `android/app/build/outputs/apk/debug/app-debug.apk`.

## Probar en el navegador del PC (opcional)
```
npm install
npm run prepare:web
npm run serve             # abre http://localhost:8080
```
La cámara funciona en `localhost`. Las pruebas de lógica: `npm test`.

## Cómo se usa
1. **Capas → Importar imágenes**: sube las partes de tu personaje como PNG con fondo transparente (cuerpo, cabeza, ojos abiertos/cerrados, pupilas, cejas, boca cerrada/abierta, pelo trasero/delantero…). Si no tienes arte aún, pulsa **Modelo de ejemplo**.
2. Elige el **Tipo de parte** de cada imagen: aplica los movimientos y condiciones típicos. Todo es ajustable.
3. Mueve las capas arrastrando en el lienzo; ajusta tamaño, rotación y **punto de giro** (por ejemplo, el cuello para la cabeza). "Usar el mismo punto de giro que…" alinea las partes de la cara.
4. **Copia espejada** crea el ojo/ceja del otro lado ya con los parámetros izquierda/derecha intercambiados.
5. **Configurar según el ángulo de tu cara**: en "Cómo se mueve con tu cara" añade movimientos (parámetro → mover/rotar/escalar/inclinar), y en "Mostrar solo cuando…" define rangos. Ejemplo: tres imágenes de cabeza (frente, 3/4 izquierda, 3/4 derecha) con el tipo correspondiente cambian solas según cuánto giras.
6. **En vivo → Iniciar cámara → Calibrar** mirando al frente.
7. Si algo se mueve al revés, activa las casillas **Invertir** en Ajustes.

## Límites actuales
- Es un sistema de capas con transformaciones (mover, rotar, escalar, inclinar, cambiar de imagen), **no** deformación de malla como Live2D Cubism; tampoco importa archivos `.psd`, `.moc3` ni `.model3.json`.
- No hay física de pelo ni accesorios todavía.
- El APK generado es de depuración (firmado con la clave debug): sirve para instalar y usar, pero no para publicar en Google Play.
