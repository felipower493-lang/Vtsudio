// Añade el permiso de cámara al AndroidManifest.xml generado por Capacitor.
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('..', import.meta.url));
const manifest = join(root, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');

if (!existsSync(manifest)) {
  console.error('No existe android/. Ejecuta primero: npm run android:add');
  process.exit(1);
}
let xml = readFileSync(manifest, 'utf8');
const add = [];
if (!xml.includes('android.permission.CAMERA')) add.push('    <uses-permission android:name="android.permission.CAMERA" />');
if (!xml.includes('android.hardware.camera"')) add.push('    <uses-feature android:name="android.hardware.camera" android:required="false" />');
if (!xml.includes('android.permission.INTERNET')) add.push('    <uses-permission android:name="android.permission.INTERNET" />');

if (add.length) {
  if (!xml.includes('<application')) {
    console.error('AndroidManifest.xml inesperado: no encuentro <application>.');
    process.exit(1);
  }
  xml = xml.replace('<application', add.join('\n') + '\n\n    <application');
  writeFileSync(manifest, xml);
  console.log('Permisos de cámara añadidos al manifiesto');
} else {
  console.log('El manifiesto ya tiene los permisos necesarios');
}
