// Copia MediaPipe (WASM + módulo) a www/vendor y descarga el modelo facial.
// Así la app funciona sin internet una vez instalada.
import { cpSync, existsSync, mkdirSync, readdirSync, statSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('..', import.meta.url));
const src = join(root, 'node_modules', '@mediapipe', 'tasks-vision');
const out = join(root, 'www', 'vendor');

if (!existsSync(src)) {
  console.error('Falta @mediapipe/tasks-vision. Ejecuta primero: npm install');
  process.exit(1);
}
mkdirSync(out, { recursive: true });

const files = readdirSync(src);
const mjs = files.find((f) => f === 'vision_bundle.mjs') || files.find((f) => /^vision_bundle.*\.mjs$/.test(f));
if (!mjs || !existsSync(join(src, 'wasm'))) {
  console.error('El paquete @mediapipe/tasks-vision no tiene la estructura esperada (vision_bundle.mjs + wasm/).');
  process.exit(1);
}
cpSync(join(src, mjs), join(out, 'vision_bundle.mjs'));
cpSync(join(src, 'wasm'), join(out, 'wasm'), { recursive: true });
console.log('MediaPipe copiado a www/vendor');

const model = join(out, 'face_landmarker.task');
const URL_MODEL = 'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task';
if (!existsSync(model) || statSync(model).size < 1_000_000) {
  console.log('Descargando modelo facial…');
  const res = await fetch(URL_MODEL);
  if (!res.ok) {
    console.error(`No se pudo descargar el modelo (${res.status}). Descárgalo manualmente de:\n${URL_MODEL}\ny guárdalo como www/vendor/face_landmarker.task`);
    process.exit(1);
  }
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length < 1_000_000) {
    console.error('El modelo descargado es demasiado pequeño; probablemente la descarga falló.');
    process.exit(1);
  }
  writeFileSync(model, buf);
  console.log(`Modelo guardado (${(buf.length / 1e6).toFixed(1)} MB)`);
} else {
  console.log('Modelo facial ya presente');
}
