import assert from 'node:assert/strict';
import {
  matrixToEuler, computeParams, smoothParams, evalLayer, defaultLayer, applyPreset,
  layerCenter, placeCenter, setPivot, pivotToPoint, mirrorLayer, hitTest, normalizeProject, PARAM_DEFAULTS,
  DEFAULT_CALIB, DEFAULT_SETTINGS, calibrationFrom,
} from '../www/js/core.js';

const rad = (d) => (d * Math.PI) / 180;
const near = (a, b, eps = 1e-6, msg = '') => assert.ok(Math.abs(a - b) < eps, `${msg} esperado ${b}, obtenido ${a}`);

// Rz(roll)*Ry(yaw)*Rx(pitch) en orden columna (como MediaPipe)
function rotMatrix(pitch, yaw, roll, scale = 1) {
  const [cx, sx] = [Math.cos(rad(pitch)), Math.sin(rad(pitch))];
  const [cy, sy] = [Math.cos(rad(yaw)), Math.sin(rad(yaw))];
  const [cz, sz] = [Math.cos(rad(roll)), Math.sin(rad(roll))];
  const Rx = [[1, 0, 0], [0, cx, -sx], [0, sx, cx]];
  const Ry = [[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]];
  const Rz = [[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]];
  const mul = (A, B) => A.map((r, i) => B[0].map((_, j) => r.reduce((s, _, k) => s + A[i][k] * B[k][j], 0)));
  const R = mul(Rz, mul(Ry, Rx));
  const m = new Array(16).fill(0);
  for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) m[c * 4 + r] = R[r][c] * scale;
  m[12] = 1.2; m[13] = -3; m[14] = -40; m[15] = 1; // traslación, no debe afectar
  return m;
}

// 1) ángulos desde la matriz
for (const [p, y, r] of [[0, 0, 0], [10, 0, 0], [0, 25, 0], [0, 0, -15], [12, -30, 8], [-20, 40, 20]]) {
  const e = matrixToEuler(rotMatrix(p, y, r, 1.07));
  near(e.pitch, p, 1e-4, 'pitch'); near(e.yaw, y, 1e-4, 'yaw'); near(e.roll, r, 1e-4, 'roll');
}

// 2) parámetros: giro, parpadeo, boca (modo espejo por defecto)
const S = { ...DEFAULT_SETTINGS };
const neutral = { euler: { pitch: 0, yaw: 0, roll: 0 }, bs: {}, nose: { x: 0.5, y: 0.5 } };
let p = computeParams(neutral, DEFAULT_CALIB, S);
near(p.angleX, 0); near(p.eyeLOpen, 1); near(p.eyeROpen, 1); near(p.mouthOpen, 0);

p = computeParams({ ...neutral, euler: { pitch: 0, yaw: 30, roll: 0 } }, DEFAULT_CALIB, S);
near(p.angleX, -1, 1e-9, 'espejo: girar a tu izquierda mueve el avatar a la izquierda de la pantalla');
p = computeParams({ ...neutral, euler: { pitch: 0, yaw: 30, roll: 0 } }, DEFAULT_CALIB, { ...S, mirror: false });
near(p.angleX, 1, 1e-9);
p = computeParams({ ...neutral, euler: { pitch: 0, yaw: 30, roll: 0 } }, DEFAULT_CALIB, { ...S, invX: true });
near(p.angleX, 1, 1e-9, 'invertir X');

p = computeParams({ ...neutral, euler: { pitch: -15, yaw: 0, roll: 0 } }, DEFAULT_CALIB, S);
near(p.angleY, 0.5, 1e-9, 'mirar arriba = +');

p = computeParams({ ...neutral, bs: { eyeBlinkLeft: 0.9, eyeBlinkRight: 0 } }, DEFAULT_CALIB, S);
near(p.eyeLOpen, 0, 1e-9); near(p.eyeROpen, 1, 1e-9);
p = computeParams({ ...neutral, bs: { eyeBlinkLeft: 0.9 } }, DEFAULT_CALIB, { ...S, mirror: false });
near(p.eyeROpen, 0, 1e-9, 'sin espejo, el ojo izquierdo del usuario es el derecho en pantalla');

p = computeParams({ ...neutral, bs: { jawOpen: 0.45, mouthSmileLeft: 0.6, mouthSmileRight: 0.6 } }, DEFAULT_CALIB, S);
near(p.mouthOpen, 1, 1e-9); near(p.mouthSmile, 1, 1e-9);

// calibración: la pose actual pasa a ser neutra
const tilted = { ...neutral, euler: { pitch: 7, yaw: 12, roll: -4 }, nose: { x: 0.4, y: 0.55 } };
const cal = calibrationFrom(tilted);
p = computeParams(tilted, cal, S);
near(p.angleX, 0); near(p.angleY, 0); near(p.angleZ, 0); near(p.bodyX, 0); near(p.bodyY, 0);

// 3) suavizado
let cur = { ...PARAM_DEFAULTS };
for (let i = 0; i < 60; i++) cur = smoothParams(cur, { ...PARAM_DEFAULTS, angleX: 1 }, { smooth: 0.5 });
near(cur.angleX, 1, 1e-6, 'converge');
const once = smoothParams(PARAM_DEFAULTS, { ...PARAM_DEFAULTS, angleX: 1, eyeLOpen: 0 }, { smooth: 0.9 });
assert.ok(once.angleX < 0.2, 'suavizado alto es lento');
assert.ok(once.eyeLOpen < 0.5, 'los ojos reaccionan rápido aunque el suavizado sea alto');

// 4) vínculos y condiciones
const head = defaultLayer({ w: 200, h: 200 }); applyPreset(head, 'head');
let t = evalLayer(head, { ...PARAM_DEFAULTS, angleX: 1, angleY: 1, angleZ: 0.5 });
near(t.x, 38); near(t.y, -26); near(t.rot, 15);

const front = defaultLayer(); applyPreset(front, 'headFront');
const left = defaultLayer(); applyPreset(left, 'headLeft');
const right = defaultLayer(); applyPreset(right, 'headRight');
for (const [ax, vis] of [[0, 'front'], [-0.8, 'left'], [0.8, 'right']]) {
  const pr = { ...PARAM_DEFAULTS, angleX: ax };
  const shown = [['front', front], ['left', left], ['right', right]].filter(([, l]) => evalLayer(l, pr)).map(([n]) => n);
  assert.deepEqual(shown, [vis], `ángulo ${ax}`);
}

const eyeOpen = defaultLayer(); applyPreset(eyeOpen, 'eyeLOpen');
const eyeClosed = defaultLayer(); applyPreset(eyeClosed, 'eyeLClosed');
assert.ok(evalLayer(eyeOpen, { ...PARAM_DEFAULTS, eyeLOpen: 1 }) && !evalLayer(eyeClosed, { ...PARAM_DEFAULTS, eyeLOpen: 1 }));
assert.ok(!evalLayer(eyeOpen, { ...PARAM_DEFAULTS, eyeLOpen: 0 }) && evalLayer(eyeClosed, { ...PARAM_DEFAULTS, eyeLOpen: 0 }));
eyeOpen.visible = false;
assert.equal(evalLayer(eyeOpen, PARAM_DEFAULTS), null);

// vínculo sobre un parámetro con valor por defecto 1: pose neutra no deforma
const squash = defaultLayer({ binds: [{ param: 'eyeLOpen', target: 'sy', amount: 0.9 }] });
near(evalLayer(squash, PARAM_DEFAULTS).sy, 1);
near(evalLayer(squash, { ...PARAM_DEFAULTS, eyeLOpen: 0 }).sy, 0.1);

// 5) pivote y colocación
const l = defaultLayer({ w: 400, h: 300, scale: 0.5, rot: 30, flipX: true });
placeCenter(l, 500, 600);
let c0 = layerCenter(l); near(c0.x, 500); near(c0.y, 600);
setPivot(l, 0.5, 0.9);
c0 = layerCenter(l); near(c0.x, 500, 1e-9, 'cambiar pivote no mueve la imagen'); near(c0.y, 600, 1e-9);
assert.ok(hitTest(l, 500, 600) && !hitTest(l, 5, 5));

// pivotToPoint: el punto de giro queda donde se pidió y la imagen no se mueve
const l2 = defaultLayer({ w: 380, h: 420, scale: 0.8, rot: 20 });
placeCenter(l2, 500, 540);
const before = layerCenter(l2);
pivotToPoint(l2, 500, 700);
near(l2.x, 500, 1e-9); near(l2.y, 700, 1e-9);
near(layerCenter(l2).x, before.x, 1e-9); near(layerCenter(l2).y, before.y, 1e-9);

// copia espejada: ojo izquierdo -> ojo derecho
const eL = defaultLayer({ name: 'Ojo', x: 428, rot: 5, w: 90, h: 70 }); applyPreset(eL, 'eyeLOpen');
const eR = mirrorLayer(eL, 1000);
assert.equal(eR.type, 'eyeROpen'); assert.equal(eR.x, 572); assert.equal(eR.rot, -5); assert.equal(eR.flipX, true);
assert.equal(eR.conds[0].param, 'eyeROpen'); assert.notEqual(eR.id, eL.id);
assert.equal(eL.conds[0].param, 'eyeLOpen', 'el original no cambia');

// 6) proyecto
const proj = normalizeProject({
  layers: [{ src: 'data:image/png;base64,AAAA', name: 'a', binds: [{ param: 'angleX', target: 'x', amount: 5 }, { param: 'nope', target: 'x', amount: 1 }] },
    { src: 'http://malo/x.png' }],
});
assert.equal(proj.layers.length, 1);
assert.equal(proj.layers[0].binds.length, 1);
assert.throws(() => normalizeProject({}));

console.log('core: todas las pruebas pasaron');
