import {
  PARAMS, PARAM_DEFAULTS, TARGETS, PRESETS, DEFAULT_CALIB, DEFAULT_SETTINGS,
  clamp, computeParams, smoothParams, calibrationFrom, evalLayer, defaultLayer, applyPreset,
  placeCenter, setPivot, pivotToPoint, mirrorLayer, hitTest, layerCenter, normalizeProject, newId,
} from './core.js';
import { kvGet, kvSet } from './store.js';
import { initTracker, detect } from './tracker.js';
import { buildDemoSpecs } from './demo.js';

const STAGE_W = 1000, STAGE_H = 1200;
const $ = (id) => document.getElementById(id);

const state = { layers: [], sel: null, settings: { ...DEFAULT_SETTINGS }, calib: { ...DEFAULT_CALIB } };
const images = new Map(); // id -> HTMLImageElement
const manual = { ...PARAM_DEFAULTS };
let params = { ...PARAM_DEFAULTS };
let tab = 'live';
let stream = null, camActive = false, lastRaw = null, lastFaceTs = 0, lastVideoTime = -1;

// ------------------------------------------------------------------ utilidades
function h(tag, props = {}, ...kids) {
  const e = document.createElement(tag);
  let value;
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') e.className = v;
    else if (k === 'value') value = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v === true) e.setAttribute(k, '');
    else if (v !== false && v != null) e.setAttribute(k, v);
  }
  for (const c of kids.flat()) if (c != null) e.append(c.nodeType ? c : document.createTextNode(String(c)));
  if (value !== undefined) e.value = value;
  return e;
}

function slider(label, min, max, step, val, onInput, fmt = (v) => v.toFixed(2)) {
  const out = h('output', {}, fmt(val));
  const inp = h('input', { type: 'range', min, max, step, value: val });
  inp.addEventListener('input', () => { const v = +inp.value; out.textContent = fmt(v); onInput(v); });
  return h('label', { class: 'field' }, h('span', {}, label), inp, out);
}

let toastT;
function toast(msg) {
  const t = $('toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2600);
}
function setStatus(msg) {
  const s = $('status');
  s.textContent = msg || ''; s.classList.toggle('show', !!msg);
}

const selLayer = () => state.layers.find((l) => l.id === state.sel) || null;

// ----------------------------------------------------------------- persistencia
let saveT;
function serialize() {
  return { format: 'vtuber-studio', version: 1, layers: state.layers, settings: state.settings, calib: state.calib };
}
function saveSoon() {
  clearTimeout(saveT);
  saveT = setTimeout(() => kvSet('project', serialize()).catch((e) => console.warn('No se pudo guardar', e)), 700);
}

function loadImage(src) {
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload = () => res(img);
    img.onerror = () => rej(new Error('Imagen no válida'));
    img.src = src;
  });
}
async function ensureImages() {
  await Promise.all(state.layers.map(async (l) => {
    if (images.has(l.id)) return;
    try { images.set(l.id, await loadImage(l.src)); } catch (e) { console.warn(e); }
  }));
}

async function setProject(p) {
  state.layers = p.layers;
  state.settings = p.settings;
  state.calib = p.calib;
  state.sel = state.layers.length ? state.layers[state.layers.length - 1].id : null;
  images.clear();
  await ensureImages();
  syncSettingsUI();
  renderAll();
}

// -------------------------------------------------------------- importar imágenes
async function fileToLayerData(file) {
  const url = URL.createObjectURL(file);
  try {
    const img = await loadImage(url);
    const k = Math.min(1, 1024 / Math.max(img.naturalWidth, img.naturalHeight));
    const w = Math.max(1, Math.round(img.naturalWidth * k)), hh = Math.max(1, Math.round(img.naturalHeight * k));
    const c = document.createElement('canvas');
    c.width = w; c.height = hh;
    c.getContext('2d').drawImage(img, 0, 0, w, hh);
    return { src: c.toDataURL('image/png'), w, h: hh, name: file.name.replace(/\.[^.]+$/, '') || 'Capa' };
  } finally { URL.revokeObjectURL(url); }
}

async function importFiles(files) {
  let n = 0;
  for (const f of files) {
    if (!f.type.startsWith('image/')) continue;
    try {
      const d = await fileToLayerData(f);
      const l = defaultLayer({ name: d.name, src: d.src, w: d.w, h: d.h });
      l.scale = Math.min(1, 700 / Math.max(d.w, d.h));
      placeCenter(l, STAGE_W / 2, STAGE_H / 2);
      state.layers.push(l);
      images.set(l.id, await loadImage(l.src));
      state.sel = l.id;
      n++;
    } catch (e) { toast(`No se pudo importar ${f.name}`); }
  }
  if (n) { toast(`${n} imagen(es) importada(s). Elige un "tipo" para vincularla a tu cara.`); saveSoon(); renderAll(); }
}

async function loadDemo() {
  const specs = buildDemoSpecs();
  for (const s of specs) {
    const l = defaultLayer({ name: s.name, src: s.src, w: s.w, h: s.h });
    applyPreset(l, s.preset);
    // Punto de giro compartido (cuello) para que las partes orbiten juntas al inclinar la cabeza.
    placeCenter(l, s.cx, s.cy);
    pivotToPoint(l, s.pivot[0], s.pivot[1]);
    state.layers.push(l);
    images.set(l.id, await loadImage(l.src));
  }
  state.sel = state.layers[state.layers.length - 1].id;
  saveSoon(); renderAll();
  toast('Modelo de ejemplo cargado. Prueba los controles manuales o inicia la cámara.');
}

// ------------------------------------------------------------------ lista de capas
function actBtn(label, title, fn) {
  return h('button', { title, 'aria-label': title, onclick: (e) => { e.stopPropagation(); fn(); } }, label);
}

function renderList() {
  const box = $('layerList');
  box.replaceChildren();
  if (!state.layers.length) {
    box.append(h('div', { class: 'empty' },
      'Aún no hay capas. Importa las partes de tu personaje (cuerpo, cabeza, ojos, boca, pelo…) como PNG con fondo transparente, o prueba el modelo de ejemplo.'));
    return;
  }
  [...state.layers].reverse().forEach((l) => {
    const idx = state.layers.indexOf(l);
    box.append(h('div', {
      class: 'layer' + (l.id === state.sel ? ' sel' : '') + (l.visible ? '' : ' hidden-layer'),
      onclick: () => { state.sel = l.id; renderList(); renderInspector(); },
    },
    h('img', { class: 'th', src: l.src, alt: '' }),
    h('div', { class: 'nm' }, l.name, h('small', {}, PRESETS[l.type]?.label || 'Libre')),
    h('div', { class: 'acts' },
      actBtn(l.visible ? '👁' : '🚫', 'Mostrar/ocultar', () => { l.visible = !l.visible; saveSoon(); renderList(); }),
      actBtn('▲', 'Subir (hacia el frente)', () => { if (idx < state.layers.length - 1) { [state.layers[idx], state.layers[idx + 1]] = [state.layers[idx + 1], state.layers[idx]]; saveSoon(); renderList(); } }),
      actBtn('▼', 'Bajar (hacia el fondo)', () => { if (idx > 0) { [state.layers[idx], state.layers[idx - 1]] = [state.layers[idx - 1], state.layers[idx]]; saveSoon(); renderList(); } }),
    )));
  });
}

// --------------------------------------------------------------------- inspector
const paramSelect = (val, onChange) =>
  h('select', { value: val, onchange: (e) => onChange(e.target.value) }, PARAMS.map((p) => h('option', { value: p.id }, p.label)));

function targetStep(t) { return t.range <= 1 ? 0.01 : 0.5; }

function renderInspector() {
  const box = $('inspector');
  box.replaceChildren();
  const l = selLayer();
  if (!l) return;

  const nameIn = h('input', { type: 'text', class: 'name', value: l.name, 'aria-label': 'Nombre de la capa' });
  nameIn.addEventListener('input', () => { l.name = nameIn.value; saveSoon(); renderList(); });
  box.append(nameIn);

  box.append(h('h3', {}, 'Tipo de parte'));
  box.append(h('select', {
    value: PRESETS[l.type] ? l.type : 'none',
    onchange: (e) => { applyPreset(l, e.target.value); saveSoon(); renderList(); renderInspector(); toast('Vínculos aplicados. Puedes ajustarlos abajo.'); },
  }, Object.entries(PRESETS).map(([k, p]) => h('option', { value: k }, p.label))));

  box.append(h('h3', {}, 'Posición y forma'));
  box.append(slider('Posición X', 0, STAGE_W, 1, l.x, (v) => { l.x = v; saveSoon(); }, (v) => v.toFixed(0)));
  box.append(slider('Posición Y', 0, STAGE_H, 1, l.y, (v) => { l.y = v; saveSoon(); }, (v) => v.toFixed(0)));
  box.append(slider('Tamaño', 0.05, 3, 0.01, l.scale, (v) => { l.scale = v; saveSoon(); }));
  box.append(slider('Rotación', -180, 180, 0.5, l.rot, (v) => { l.rot = v; saveSoon(); }, (v) => v.toFixed(0) + '°'));
  box.append(slider('Opacidad', 0, 1, 0.01, l.opacity, (v) => { l.opacity = v; saveSoon(); }));
  const pivX = slider('Giro: X', -0.5, 1.5, 0.01, l.px, (v) => { setPivot(l, v, l.py); saveSoon(); });
  const pivY = slider('Giro: Y', -0.5, 1.5, 0.01, l.py, (v) => { setPivot(l, l.px, v); saveSoon(); });
  for (const p of [pivX, pivY]) p.querySelector('input').addEventListener('change', renderInspector);
  box.append(pivX, pivY);
  box.append(h('p', { class: 'hint' }, 'El "punto de giro" es el eje sobre el que rota la capa (por ejemplo, el cuello para la cabeza).'));

  const others = state.layers.filter((o) => o.id !== l.id);
  if (others.length) {
    box.append(h('select', {
      onchange: (e) => {
        const o = state.layers.find((x) => x.id === e.target.value);
        if (o) { pivotToPoint(l, o.x, o.y); saveSoon(); renderInspector(); toast('Punto de giro copiado'); }
      },
    }, h('option', { value: '' }, 'Usar el mismo punto de giro que…'), others.map((o) => h('option', { value: o.id }, o.name))));
  }

  box.append(h('label', { class: 'check' },
    h('input', { type: 'checkbox', ...(l.flipX ? { checked: true } : {}), onchange: (e) => { l.flipX = e.target.checked; saveSoon(); } }),
    'Voltear horizontalmente'));

  // Vínculos
  box.append(h('h3', {}, 'Cómo se mueve con tu cara'));
  l.binds.forEach((bd, i) => {
    const tg = TARGETS.find((t) => t.id === bd.target) || TARGETS[0];
    const max = Math.max(tg.range, Math.ceil(Math.abs(bd.amount) * 1.25));
    box.append(h('div', { class: 'bind' },
      h('div', { class: 'top' },
        paramSelect(bd.param, (v) => { bd.param = v; saveSoon(); }),
        h('button', { class: 'del', title: 'Quitar', onclick: () => { l.binds.splice(i, 1); saveSoon(); renderInspector(); } }, '✕')),
      h('select', { value: bd.target, onchange: (e) => { bd.target = e.target.value; saveSoon(); renderInspector(); } },
        TARGETS.map((t) => h('option', { value: t.id }, t.label))),
      slider('Cantidad', -max, max, targetStep(tg), bd.amount, (v) => { bd.amount = v; saveSoon(); }, (v) => v.toFixed(tg.range <= 1 ? 2 : 1))));
  });
  box.append(h('button', { onclick: () => { l.binds.push({ param: 'angleX', target: 'x', amount: 20 }); saveSoon(); renderInspector(); } }, '+ Añadir movimiento'));

  // Condiciones
  box.append(h('h3', {}, 'Mostrar solo cuando…'));
  if (!l.conds.length) box.append(h('p', { class: 'hint' }, 'Sin condiciones: la capa siempre se ve. Úsalas para cambiar imágenes según el ángulo, parpadeo o boca.'));
  l.conds.forEach((c, i) => {
    const num = (key) => {
      const inp = h('input', { type: 'number', step: 0.05, value: c[key], 'aria-label': key === 'min' ? 'Mínimo' : 'Máximo' });
      inp.addEventListener('change', () => { const v = parseFloat(inp.value); if (Number.isFinite(v)) { c[key] = v; saveSoon(); } });
      return inp;
    };
    box.append(h('div', { class: 'cond' },
      paramSelect(c.param, (v) => { c.param = v; saveSoon(); }),
      num('min'), num('max'),
      h('button', { class: 'del', title: 'Quitar', onclick: () => { l.conds.splice(i, 1); saveSoon(); renderInspector(); } }, '✕')));
  });
  box.append(h('button', { onclick: () => { l.conds.push({ param: 'angleX', min: -0.33, max: 0.33 }); saveSoon(); renderInspector(); } }, '+ Añadir condición'));

  // Acciones
  box.append(h('h3', {}, 'Acciones'));
  box.append(h('div', { class: 'row wrap' },
    h('button', { onclick: () => duplicate(l, false) }, 'Duplicar'),
    h('button', { onclick: () => duplicate(l, true) }, 'Copia espejada'),
    h('button', { class: 'danger', onclick: () => removeLayer(l) }, 'Eliminar')));
}

function duplicate(l, mirrored) {
  let c;
  if (mirrored) c = mirrorLayer(l, STAGE_W);
  else { c = JSON.parse(JSON.stringify(l)); c.id = newId(); c.name = `${l.name} copia`; c.x += 24; c.y += 24; }
  state.layers.splice(state.layers.indexOf(l) + 1, 0, c);
  images.set(c.id, images.get(l.id));
  state.sel = c.id;
  saveSoon(); renderAll();
}
function removeLayer(l) {
  if (!confirm(`¿Eliminar "${l.name}"?`)) return;
  const i = state.layers.indexOf(l);
  state.layers.splice(i, 1);
  if (!state.layers.some((o) => o.src === l.src)) images.delete(l.id);
  state.sel = state.layers.length ? state.layers[Math.min(i, state.layers.length - 1)].id : null;
  saveSoon(); renderAll();
}

// ------------------------------------------------------------- sliders de prueba y medidores
function buildTestSliders() {
  const box = $('testSliders');
  box.replaceChildren();
  for (const p of PARAMS) {
    box.append(slider(p.label, p.min, p.max, 0.01, manual[p.id], (v) => { manual[p.id] = v; }));
  }
}
const meterEls = {};
function buildMeters() {
  const box = $('meters');
  box.replaceChildren();
  for (const p of PARAMS) {
    const fill = h('i');
    meterEls[p.id] = fill;
    box.append(h('div', { class: 'meter' }, h('span', {}, p.label), h('div', { class: 'bar' }, fill)));
  }
}
function updateMeters() {
  for (const p of PARAMS) {
    const f = meterEls[p.id];
    if (!f) continue;
    const v = clamp(params[p.id], p.min, p.max);
    const a = (v - p.min) / (p.max - p.min);
    // Parámetros centrados (-1..1): barra desde el centro. Parámetros 0..1: barra desde el inicio.
    const z = p.min < 0 ? (0 - p.min) / (p.max - p.min) : 0;
    f.style.left = Math.min(a, z) * 100 + '%';
    f.style.width = Math.max(Math.abs(a - z) * 100, 1.5) + '%';
  }
}

// ------------------------------------------------------------------------ ajustes
function syncSettingsUI() {
  const s = state.settings;
  $('setMirror').checked = s.mirror;
  $('setInvX').checked = s.invX; $('setInvY').checked = s.invY; $('setInvZ').checked = s.invZ;
  $('setBg').value = s.bg;
  $('manualOverride').checked = s.manualOverride;
  const box = $('setSliders');
  box.replaceChildren(
    slider('Sensibilidad', 0.4, 2.5, 0.05, s.sens, (v) => { s.sens = v; saveSoon(); }),
    slider('Suavizado', 0, 0.9, 0.01, s.smooth, (v) => { s.smooth = v; saveSoon(); }));
}

function bindSettings() {
  const s = () => state.settings;
  $('setMirror').onchange = (e) => { s().mirror = e.target.checked; saveSoon(); };
  $('setInvX').onchange = (e) => { s().invX = e.target.checked; saveSoon(); };
  $('setInvY').onchange = (e) => { s().invY = e.target.checked; saveSoon(); };
  $('setInvZ').onchange = (e) => { s().invZ = e.target.checked; saveSoon(); };
  $('setBg').oninput = (e) => { s().bg = e.target.value; saveSoon(); };
  $('bgGreen').onclick = () => { s().bg = '#00b140'; $('setBg').value = s().bg; saveSoon(); };
  $('bgDark').onclick = () => { s().bg = DEFAULT_SETTINGS.bg; $('setBg').value = s().bg; saveSoon(); };
  $('manualOverride').onchange = (e) => { s().manualOverride = e.target.checked; saveSoon(); };
  $('exportBtn').onclick = exportProject;
  $('importBtn').onclick = () => $('fileProj').click();
  $('fileProj').onchange = async (e) => {
    const f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    try { await setProject(normalizeProject(JSON.parse(await f.text()))); saveSoon(); toast('Modelo importado'); }
    catch (err) { toast('No se pudo importar: ' + err.message); }
  };
  $('clearBtn').onclick = async () => {
    if (!confirm('¿Borrar todas las capas y ajustes? Esto no se puede deshacer.')) return;
    await setProject({ layers: [], settings: { ...DEFAULT_SETTINGS }, calib: { ...DEFAULT_CALIB } });
    saveSoon();
  };
}

async function exportProject() {
  const json = JSON.stringify(serialize());
  const name = 'modelo-vtuber.json';
  const cap = window.Capacitor;
  if (cap?.isNativePlatform?.() && cap.Plugins?.Filesystem && cap.Plugins?.Share) {
    try {
      const r = await cap.Plugins.Filesystem.writeFile({ path: name, data: json, directory: 'CACHE', encoding: 'utf8' });
      await cap.Plugins.Share.share({ title: name, url: r.uri });
      return;
    } catch (e) { console.warn('Compartir falló, intento descarga', e); }
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([json], { type: 'application/json' }));
  a.download = name;
  document.body.append(a); a.click(); a.remove();
  toast('Archivo exportado');
}

// ------------------------------------------------------------------------ cámara
async function startCamera() {
  const btn = $('camBtn');
  btn.disabled = true;
  try {
    setStatus('Cargando seguimiento facial…');
    await initTracker();
    setStatus('Pidiendo acceso a la cámara…');
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } }, audio: false });
    const v = $('cam');
    v.srcObject = stream;
    await v.play();
    v.classList.add('on');
    camActive = true; lastVideoTime = -1; lastFaceTs = performance.now();
    btn.textContent = 'Detener cámara';
    $('calBtn').disabled = false;
    setStatus('');
    try { await navigator.wakeLock?.request('screen'); } catch (e) { /* opcional */ }
  } catch (e) {
    console.error(e);
    const denied = e && (e.name === 'NotAllowedError' || e.name === 'SecurityError');
    setStatus(denied ? 'Permiso de cámara denegado. Actívalo en los ajustes del teléfono.' : 'No se pudo iniciar: ' + (e.message || e));
    stopCamera(true);
  } finally { btn.disabled = false; }
}
function stopCamera(keepStatus) {
  camActive = false;
  stream?.getTracks().forEach((t) => t.stop());
  stream = null;
  $('cam').classList.remove('on');
  $('camBtn').textContent = 'Iniciar cámara';
  $('calBtn').disabled = true;
  lastRaw = null;
  if (!keepStatus) setStatus('');
}
function calibrate() {
  if (!lastRaw) { toast('No veo tu cara. Colócate frente a la cámara.'); return; }
  state.calib = calibrationFrom(lastRaw);
  saveSoon();
  toast('Calibrado: esta postura es ahora la neutra');
}

// ------------------------------------------------------------------------ dibujo
const canvas = $('stage');
const ctx = canvas.getContext('2d');
let cw = 0, ch = 0, dpr = 1;

function resize() {
  const r = canvas.getBoundingClientRect();
  dpr = Math.min(window.devicePixelRatio || 1, 2.5);
  cw = Math.max(1, Math.round(r.width)); ch = Math.max(1, Math.round(r.height));
  canvas.width = Math.round(cw * dpr); canvas.height = Math.round(ch * dpr);
}
new ResizeObserver(resize).observe(canvas);

function view() {
  const k = Math.min(cw / STAGE_W, ch / STAGE_H);
  return { k, ox: (cw - STAGE_W * k) / 2, oy: (ch - STAGE_H * k) / 2 };
}

function drawLayer(l, t) {
  const img = images.get(l.id);
  if (!img) return;
  ctx.save();
  ctx.translate(l.x + t.x, l.y + t.y);
  ctx.rotate(((l.rot + t.rot) * Math.PI) / 180);
  ctx.scale(l.scale * t.sx * (l.flipX ? -1 : 1), l.scale * t.sy);
  if (t.skew) ctx.transform(1, 0, Math.tan((t.skew * Math.PI) / 180), 1, 0, 0);
  ctx.globalAlpha = l.opacity;
  ctx.drawImage(img, -l.px * l.w, -l.py * l.h, l.w, l.h);
  ctx.restore();
}

function drawSelection(l) {
  ctx.save();
  ctx.translate(l.x, l.y);
  ctx.rotate((l.rot * Math.PI) / 180);
  ctx.scale(l.scale * (l.flipX ? -1 : 1), l.scale);
  ctx.strokeStyle = '#7c8cff'; ctx.lineWidth = 2 / (view().k * l.scale); ctx.setLineDash([8 / (view().k * l.scale), 6 / (view().k * l.scale)]);
  ctx.strokeRect(-l.px * l.w, -l.py * l.h, l.w, l.h);
  ctx.setLineDash([]);
  const r = 9 / (view().k * l.scale);
  ctx.strokeStyle = '#5be3b8'; ctx.beginPath();
  ctx.moveTo(-r, 0); ctx.lineTo(r, 0); ctx.moveTo(0, -r); ctx.lineTo(0, r); ctx.stroke();
  ctx.restore();
}

function draw() {
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = state.settings.bg;
  ctx.fillRect(0, 0, cw, ch);
  const { k, ox, oy } = view();
  ctx.save();
  ctx.translate(ox, oy); ctx.scale(k, k);
  ctx.imageSmoothingQuality = 'high';
  if (tab === 'layers') {
    ctx.strokeStyle = 'rgba(255,255,255,.12)'; ctx.lineWidth = 2 / k;
    ctx.strokeRect(0, 0, STAGE_W, STAGE_H);
  }
  for (const l of state.layers) {
    const t = evalLayer(l, params);
    if (t) drawLayer(l, t);
  }
  const s = selLayer();
  if (tab === 'layers' && s) drawSelection(s);
  ctx.restore();
  if (!state.layers.length) {
    ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.font = '600 15px system-ui'; ctx.textAlign = 'center';
    ctx.fillText('Ve a "Capas" para importar tus imágenes', cw / 2, ch / 2);
  }
}

// ---------------------------------------------------------------------- bucle principal
let meterT = 0;
function tick(now) {
  requestAnimationFrame(tick);
  const v = $('cam');
  if (camActive && v.readyState >= 2 && v.currentTime !== lastVideoTime) {
    lastVideoTime = v.currentTime;
    try { lastRaw = detect(v, performance.now()); } catch (e) { console.warn(e); lastRaw = null; }
    if (lastRaw) { lastFaceTs = now; if ($('status').textContent.startsWith('Sin cara')) setStatus(''); }
  }
  if (camActive && now - lastFaceTs > 800) { lastRaw = null; setStatus('Sin cara detectada'); }

  const useCam = camActive && lastRaw && !state.settings.manualOverride;
  const target = useCam ? computeParams(lastRaw, state.calib, state.settings) : manual;
  params = smoothParams(params, target, state.settings);
  draw();
  if (tab === 'live' && now - meterT > 100) { meterT = now; updateMeters(); }
}

// --------------------------------------------------------------- arrastrar en el lienzo
let drag = null;
function toStage(ev) {
  const r = canvas.getBoundingClientRect();
  const { k, ox, oy } = view();
  return { x: (ev.clientX - r.left - ox) / k, y: (ev.clientY - r.top - oy) / k };
}
canvas.addEventListener('pointerdown', (ev) => {
  if (tab !== 'layers') return;
  const p = toStage(ev);
  let hit = null;
  for (let i = state.layers.length - 1; i >= 0; i--) {
    const l = state.layers[i];
    if (evalLayer(l, params) && hitTest(l, p.x, p.y)) { hit = l; break; }
  }
  if (!hit) return;
  if (state.sel !== hit.id) { state.sel = hit.id; renderList(); renderInspector(); }
  drag = { l: hit, dx: hit.x - p.x, dy: hit.y - p.y };
  canvas.setPointerCapture(ev.pointerId);
});
canvas.addEventListener('pointermove', (ev) => {
  if (!drag) return;
  const p = toStage(ev);
  drag.l.x = clamp(p.x + drag.dx, -200, STAGE_W + 200);
  drag.l.y = clamp(p.y + drag.dy, -200, STAGE_H + 200);
  saveSoon();
});
const endDrag = () => { if (drag) { drag = null; renderInspector(); } };
canvas.addEventListener('pointerup', endDrag);
canvas.addEventListener('pointercancel', endDrag);

// --------------------------------------------------------------------------- UI
function renderAll() { renderList(); renderInspector(); }

function showTab(name) {
  tab = name;
  for (const b of document.querySelectorAll('#tabs button')) b.classList.toggle('on', b.dataset.tab === name);
  for (const s of document.querySelectorAll('.tab')) s.hidden = s.id !== 'tab-' + name;
}

function bindUI() {
  for (const b of document.querySelectorAll('#tabs button')) b.addEventListener('click', () => showTab(b.dataset.tab));
  $('camBtn').onclick = () => (camActive ? stopCamera() : startCamera());
  $('calBtn').onclick = calibrate;
  $('addImgBtn').onclick = () => $('fileImg').click();
  $('fileImg').onchange = async (e) => { const f = [...e.target.files]; e.target.value = ''; await importFiles(f); };
  $('demoBtn').onclick = loadDemo;
  $('resetTest').onclick = () => { Object.assign(manual, PARAM_DEFAULTS); buildTestSliders(); };
  bindSettings();
}

async function init() {
  buildMeters(); buildTestSliders(); bindUI();
  try {
    const saved = await kvGet('project');
    if (saved) await setProject(normalizeProject(saved));
    else { syncSettingsUI(); renderAll(); }
  } catch (e) {
    console.warn('No se pudo cargar el proyecto guardado', e);
    syncSettingsUI(); renderAll();
  }
  resize();
  requestAnimationFrame(tick);
}

// Expuesto para pruebas manuales desde la consola.
window.__vtuber = { state, manual, get params() { return params; } };
init();
