// Lógica pura (sin DOM): parámetros de la cara, vínculos de capas, presets.
// Se prueba con `npm test` (tests/core.test.mjs).

export const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
export const lerp = (a, b, t) => a + (b - a) * t;
const DEG = 180 / Math.PI;
const smoothstep = (a, b, x) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};

// ---------------------------------------------------------------- parámetros
export const PARAMS = [
  { id: 'angleX', label: 'Giro de cabeza (izq/der)', min: -1, max: 1, def: 0 },
  { id: 'angleY', label: 'Cabeza arriba/abajo', min: -1, max: 1, def: 0 },
  { id: 'angleZ', label: 'Inclinación de cabeza', min: -1, max: 1, def: 0 },
  { id: 'eyeLOpen', label: 'Ojo izquierdo abierto', min: 0, max: 1, def: 1 },
  { id: 'eyeROpen', label: 'Ojo derecho abierto', min: 0, max: 1, def: 1 },
  { id: 'eyeX', label: 'Mirada izq/der', min: -1, max: 1, def: 0 },
  { id: 'eyeY', label: 'Mirada arriba/abajo', min: -1, max: 1, def: 0 },
  { id: 'mouthOpen', label: 'Boca abierta', min: 0, max: 1, def: 0 },
  { id: 'mouthSmile', label: 'Sonrisa', min: 0, max: 1, def: 0 },
  { id: 'browL', label: 'Ceja izquierda', min: -1, max: 1, def: 0 },
  { id: 'browR', label: 'Ceja derecha', min: -1, max: 1, def: 0 },
  { id: 'bodyX', label: 'Posición horizontal', min: -1, max: 1, def: 0 },
  { id: 'bodyY', label: 'Posición vertical', min: -1, max: 1, def: 0 },
];
export const PARAM_DEFAULTS = Object.fromEntries(PARAMS.map((p) => [p.id, p.def]));

export const TARGETS = [
  { id: 'x', label: 'Mover horizontal (px)', range: 150 },
  { id: 'y', label: 'Mover vertical (px)', range: 150 },
  { id: 'rot', label: 'Rotar (grados)', range: 45 },
  { id: 'sx', label: 'Escala horizontal', range: 1 },
  { id: 'sy', label: 'Escala vertical', range: 1 },
  { id: 'skew', label: 'Inclinar (grados)', range: 30 },
];

// ------------------------------------------------- matriz de MediaPipe -> ángulos
// `m` es la matriz 4x4 en orden columna (facialTransformationMatrixes[i].data).
export function matrixToEuler(m) {
  const R = (r, c) => m[c * 4 + r];
  const n = (c) => Math.hypot(R(0, c), R(1, c), R(2, c)) || 1;
  const n0 = n(0), n1 = n(1), n2 = n(2);
  const r00 = R(0, 0) / n0, r10 = R(1, 0) / n0, r20 = R(2, 0) / n0;
  const r11 = R(1, 1) / n1, r21 = R(2, 1) / n1;
  const r12 = R(1, 2) / n2, r22 = R(2, 2) / n2;
  const s = Math.hypot(r00, r10);
  let pitch, yaw, roll;
  if (s > 1e-6) {
    pitch = Math.atan2(r21, r22);
    yaw = Math.atan2(-r20, s);
    roll = Math.atan2(r10, r00);
  } else {
    pitch = Math.atan2(-r12, r11);
    yaw = Math.atan2(-r20, s);
    roll = 0;
  }
  return { pitch: pitch * DEG, yaw: yaw * DEG, roll: roll * DEG };
}

// raw = { euler:{pitch,yaw,roll}, bs:{nombre:valor}, nose:{x,y} }
export function calibrationFrom(raw) {
  return {
    yaw: raw.euler.yaw, pitch: raw.euler.pitch, roll: raw.euler.roll,
    nx: raw.nose ? raw.nose.x : 0.5, ny: raw.nose ? raw.nose.y : 0.5,
  };
}

export const DEFAULT_CALIB = { yaw: 0, pitch: 0, roll: 0, nx: 0.5, ny: 0.5 };
export const DEFAULT_SETTINGS = {
  mirror: true, sens: 1, smooth: 0.5, invX: false, invY: false, invZ: false,
  bg: '#1b1d27', manualOverride: false,
};

export function computeParams(raw, calib, s) {
  const m = s.mirror ? -1 : 1; // en espejo, izquierda de pantalla = izquierda del usuario
  const range = 30 / (s.sens || 1); // 30° de giro real = 1.0
  const e = raw.euler;
  const g = (k) => raw.bs[k] || 0;
  const out = {};
  out.angleX = clamp((m * (e.yaw - calib.yaw)) / range, -1.5, 1.5) * (s.invX ? -1 : 1);
  out.angleY = clamp(-(e.pitch - calib.pitch) / range, -1.5, 1.5) * (s.invY ? -1 : 1);
  out.angleZ = clamp((-m * (e.roll - calib.roll)) / range, -1.5, 1.5) * (s.invZ ? -1 : 1);

  const blinkL = s.mirror ? g('eyeBlinkLeft') : g('eyeBlinkRight');
  const blinkR = s.mirror ? g('eyeBlinkRight') : g('eyeBlinkLeft');
  out.eyeLOpen = 1 - smoothstep(0.25, 0.65, blinkL);
  out.eyeROpen = 1 - smoothstep(0.25, 0.65, blinkR);

  const gxRaw = (g('eyeLookOutLeft') - g('eyeLookInLeft') + g('eyeLookInRight') - g('eyeLookOutRight')) / 2;
  out.eyeX = clamp(m * gxRaw * 1.8, -1, 1);
  const up = (g('eyeLookUpLeft') + g('eyeLookUpRight')) / 2;
  const down = (g('eyeLookDownLeft') + g('eyeLookDownRight')) / 2;
  out.eyeY = clamp((up - down) * 1.8, -1, 1);

  out.mouthOpen = clamp(g('jawOpen') / 0.45, 0, 1);
  out.mouthSmile = clamp((g('mouthSmileLeft') + g('mouthSmileRight')) / 2 / 0.6, 0, 1);

  const brow = (side) => {
    const up2 = (g('browInnerUp') + g('browOuterUp' + side)) / 2;
    return clamp((up2 - g('browDown' + side)) * 1.8, -1, 1);
  };
  const bl = s.mirror ? 'Left' : 'Right';
  const br = s.mirror ? 'Right' : 'Left';
  out.browL = brow(bl);
  out.browR = brow(br);

  const nose = raw.nose || { x: calib.nx, y: calib.ny };
  out.bodyX = clamp((m * (nose.x - calib.nx)) / 0.15, -1.5, 1.5);
  out.bodyY = clamp(-(nose.y - calib.ny) / 0.15, -1.5, 1.5);
  return out;
}

// Suavizado exponencial; ojos y boca reaccionan más rápido para no perder parpadeos.
export function smoothParams(prev, target, s) {
  const base = 1 - clamp(s.smooth ?? 0.5, 0, 0.95);
  const out = {};
  for (const p of PARAMS) {
    let a = base;
    if (p.id.startsWith('eye') && p.id.endsWith('Open')) a = Math.max(base, 0.6);
    else if (p.id === 'mouthOpen' || p.id === 'mouthSmile') a = Math.max(base, 0.45);
    const t = target[p.id] ?? p.def;
    const v = prev[p.id] ?? p.def;
    out[p.id] = v + (t - v) * a;
  }
  return out;
}

// ----------------------------------------------------------------- capas
let idCounter = 0;
export const newId = () => `l${Date.now().toString(36)}${(idCounter++).toString(36)}`;

export function defaultLayer(p = {}) {
  return {
    id: p.id || newId(), name: 'Capa', type: 'none', src: '', w: 100, h: 100,
    x: 500, y: 600, scale: 1, rot: 0, px: 0.5, py: 0.5, opacity: 1, flipX: false,
    visible: true, binds: [], conds: [], ...p,
  };
}

// Devuelve la transformación final de la capa o null si no debe mostrarse.
export function evalLayer(layer, params) {
  if (!layer.visible) return null;
  for (const c of layer.conds) {
    const v = params[c.param];
    if (v === undefined || v < c.min || v > c.max) return null;
  }
  const t = { x: 0, y: 0, rot: 0, sx: 1, sy: 1, skew: 0 };
  for (const b of layer.binds) {
    const delta = (params[b.param] ?? 0) - (PARAM_DEFAULTS[b.param] ?? 0);
    const a = delta * b.amount;
    if (b.target === 'x') t.x += a;
    else if (b.target === 'y') t.y += a;
    else if (b.target === 'rot') t.rot += a;
    else if (b.target === 'sx') t.sx *= Math.max(0.02, 1 + a);
    else if (b.target === 'sy') t.sy *= Math.max(0.02, 1 + a);
    else if (b.target === 'skew') t.skew += a;
  }
  return t;
}

const rot2 = (x, y, deg) => {
  const r = (deg * Math.PI) / 180, c = Math.cos(r), s = Math.sin(r);
  return [x * c - y * s, x * s + y * c];
};
const pivotOffset = (l) => rot2((0.5 - l.px) * l.w * l.scale * (l.flipX ? -1 : 1), (0.5 - l.py) * l.h * l.scale, l.rot);

// Centro visual de la imagen en el escenario (sin parámetros aplicados).
export function layerCenter(l) {
  const [ox, oy] = pivotOffset(l);
  return { x: l.x + ox, y: l.y + oy };
}
// Coloca la capa para que el centro de su imagen quede en (cx, cy).
export function placeCenter(l, cx, cy) {
  const [ox, oy] = pivotOffset(l);
  l.x = cx - ox;
  l.y = cy - oy;
}
// Cambia el pivote sin que la imagen se mueva visualmente.
export function setPivot(l, px, py) {
  const c = layerCenter(l);
  l.px = clamp(px, -1, 2);
  l.py = clamp(py, -1, 2);
  placeCenter(l, c.x, c.y);
}

// Mueve el punto de giro a (sx, sy) del escenario; la imagen no se mueve.
export function pivotToPoint(l, sx, sy) {
  const c = layerCenter(l);
  const [lx, ly] = rot2(c.x - sx, c.y - sy, -l.rot);
  const f = l.flipX ? -1 : 1;
  l.px = clamp(0.5 - lx / (l.w * l.scale * f), -1, 2);
  l.py = clamp(0.5 - ly / (l.h * l.scale), -1, 2);
  placeCenter(l, c.x, c.y);
}

const SWAP = { eyeLOpen: 'eyeROpen', eyeROpen: 'eyeLOpen', browL: 'browR', browR: 'browL' };
const SWAP_TYPE = {
  eyeLOpen: 'eyeROpen', eyeROpen: 'eyeLOpen', eyeLClosed: 'eyeRClosed', eyeRClosed: 'eyeLClosed',
  pupilL: 'pupilR', pupilR: 'pupilL', browL: 'browR', browR: 'browL',
  headLeft: 'headRight', headRight: 'headLeft',
};
// Copia espejada respecto al eje vertical central del escenario (para el 2º ojo, 2ª ceja…).
export function mirrorLayer(l, stageW = 1000) {
  const m = JSON.parse(JSON.stringify(l));
  m.id = newId();
  m.name = `${l.name} (espejo)`;
  m.x = stageW - l.x;
  m.rot = -l.rot;
  m.flipX = !l.flipX;
  m.type = SWAP_TYPE[l.type] || l.type;
  m.binds.forEach((b) => { b.param = SWAP[b.param] || b.param; });
  m.conds.forEach((k) => { k.param = SWAP[k.param] || k.param; });
  return m;
}

// ¿(mx,my) del escenario cae dentro de la capa (sin parámetros)?
export function hitTest(l, mx, my) {
  let [x, y] = rot2(mx - l.x, my - l.y, -l.rot);
  x /= l.scale; y /= l.scale;
  if (l.flipX) x = -x;
  return x >= -l.px * l.w && x <= (1 - l.px) * l.w && y >= -l.py * l.h && y <= (1 - l.py) * l.h;
}

// ---------------------------------------------------------------- presets
const b = (param, target, amount) => ({ param, target, amount });
const c = (param, min, max) => ({ param, min, max });
const faceFollow = () => [
  b('angleX', 'x', 50), b('angleY', 'y', -34), b('angleZ', 'rot', 30),
  b('bodyX', 'x', 70), b('bodyY', 'y', -50),
];
const headFollow = () => [
  b('angleX', 'x', 38), b('angleY', 'y', -26), b('angleZ', 'rot', 30),
  b('bodyX', 'x', 70), b('bodyY', 'y', -50),
];

export const PRESETS = {
  none: { label: 'Libre (sin vínculos)', binds: () => [], conds: () => [] },
  body: {
    label: 'Cuerpo',
    binds: () => [b('angleX', 'x', 14), b('angleY', 'y', -6), b('angleZ', 'rot', 4), b('bodyX', 'x', 70), b('bodyY', 'y', -30)],
    conds: () => [],
  },
  head: { label: 'Cabeza / cara', binds: headFollow, conds: () => [] },
  headFront: { label: 'Cabeza de frente (ángulo)', binds: headFollow, conds: () => [c('angleX', -0.33, 0.33)] },
  headLeft: { label: 'Cabeza 3/4 izquierda (ángulo)', binds: headFollow, conds: () => [c('angleX', -1.5, -0.33)] },
  headRight: { label: 'Cabeza 3/4 derecha (ángulo)', binds: headFollow, conds: () => [c('angleX', 0.33, 1.5)] },
  hairBack: {
    label: 'Pelo trasero',
    binds: () => [b('angleX', 'x', 24), b('angleY', 'y', -16), b('angleZ', 'rot', 26), b('bodyX', 'x', 70), b('bodyY', 'y', -50)],
    conds: () => [],
  },
  hairFront: {
    label: 'Pelo delantero',
    binds: () => [b('angleX', 'x', 62), b('angleY', 'y', -38), b('angleZ', 'rot', 30), b('bodyX', 'x', 70), b('bodyY', 'y', -50)],
    conds: () => [],
  },
  eyeLOpen: { label: 'Ojo izq. abierto', binds: faceFollow, conds: () => [c('eyeLOpen', 0.35, 1)] },
  eyeLClosed: { label: 'Ojo izq. cerrado', binds: faceFollow, conds: () => [c('eyeLOpen', 0, 0.35)] },
  eyeROpen: { label: 'Ojo der. abierto', binds: faceFollow, conds: () => [c('eyeROpen', 0.35, 1)] },
  eyeRClosed: { label: 'Ojo der. cerrado', binds: faceFollow, conds: () => [c('eyeROpen', 0, 0.35)] },
  pupilL: {
    label: 'Pupila izquierda',
    binds: () => [...faceFollow(), b('eyeX', 'x', 9), b('eyeY', 'y', -7)],
    conds: () => [c('eyeLOpen', 0.35, 1)],
  },
  pupilR: {
    label: 'Pupila derecha',
    binds: () => [...faceFollow(), b('eyeX', 'x', 9), b('eyeY', 'y', -7)],
    conds: () => [c('eyeROpen', 0.35, 1)],
  },
  mouthClosed: { label: 'Boca cerrada', binds: faceFollow, conds: () => [c('mouthOpen', 0, 0.2)] },
  mouthOpen: { label: 'Boca abierta', binds: faceFollow, conds: () => [c('mouthOpen', 0.2, 1)] },
  browL: { label: 'Ceja izquierda', binds: () => [...faceFollow(), b('browL', 'y', -16)], conds: () => [] },
  browR: { label: 'Ceja derecha', binds: () => [...faceFollow(), b('browR', 'y', -16)], conds: () => [] },
  accessory: { label: 'Accesorio (sigue la cabeza)', binds: headFollow, conds: () => [] },
};

export function applyPreset(layer, key) {
  const p = PRESETS[key];
  if (!p) return;
  layer.type = key;
  layer.binds = p.binds();
  layer.conds = p.conds();
}

// ------------------------------------------------- validar proyecto importado
export function normalizeProject(obj) {
  if (!obj || typeof obj !== 'object' || !Array.isArray(obj.layers)) throw new Error('Archivo de proyecto no válido');
  const layers = obj.layers
    .filter((l) => l && typeof l.src === 'string' && l.src.startsWith('data:image/'))
    .map((l) => {
      const d = defaultLayer();
      const out = { ...d };
      for (const k of ['id', 'name', 'type', 'src']) if (typeof l[k] === 'string') out[k] = l[k];
      for (const k of ['w', 'h', 'x', 'y', 'scale', 'rot', 'px', 'py', 'opacity']) if (Number.isFinite(l[k])) out[k] = l[k];
      out.flipX = !!l.flipX;
      out.visible = l.visible !== false;
      out.binds = Array.isArray(l.binds)
        ? l.binds.filter((x) => x && PARAM_DEFAULTS[x.param] !== undefined && TARGETS.some((t) => t.id === x.target) && Number.isFinite(x.amount))
            .map((x) => ({ param: x.param, target: x.target, amount: x.amount }))
        : [];
      out.conds = Array.isArray(l.conds)
        ? l.conds.filter((x) => x && PARAM_DEFAULTS[x.param] !== undefined && Number.isFinite(x.min) && Number.isFinite(x.max))
            .map((x) => ({ param: x.param, min: x.min, max: x.max }))
        : [];
      return out;
    });
  return {
    layers,
    settings: { ...DEFAULT_SETTINGS, ...(obj.settings || {}) },
    calib: { ...DEFAULT_CALIB, ...(obj.calib || {}) },
  };
}
