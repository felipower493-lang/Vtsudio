// Modelo de ejemplo dibujado por código, para probar la app sin tener tus propias imágenes.
const ell = (x, cx, cy, rx, ry) => { x.beginPath(); x.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2); };
const NECK = [500, 700];

export const DEMO = [
  { name: 'Pelo trasero', preset: 'hairBack', w: 500, h: 640, cx: 500, cy: 590, draw(x, w, h) {
    x.fillStyle = '#5b3f9a';
    ell(x, w / 2, h * 0.42, w * 0.47, h * 0.4); x.fill();
    x.beginPath(); x.roundRect(w * 0.05, h * 0.4, w * 0.9, h * 0.58, 70); x.fill();
  } },
  { name: 'Cuerpo', preset: 'body', w: 540, h: 480, cx: 500, cy: 960, pivot: [500, 1180], draw(x, w, h) {
    x.fillStyle = '#e7edf7';
    x.beginPath(); x.moveTo(w * 0.1, h); x.quadraticCurveTo(w * 0.1, h * 0.25, w * 0.5, h * 0.2);
    x.quadraticCurveTo(w * 0.9, h * 0.25, w * 0.9, h); x.closePath(); x.fill();
    x.fillStyle = '#f6d7c3'; x.fillRect(w * 0.42, 0, w * 0.16, h * 0.3);
    x.fillStyle = '#7c8cff'; x.beginPath(); x.moveTo(w * 0.35, h * 0.2); x.lineTo(w * 0.5, h * 0.45); x.lineTo(w * 0.65, h * 0.2); x.fill();
  } },
  { name: 'Cabeza', preset: 'head', w: 380, h: 420, cx: 500, cy: 540, draw(x, w, h) {
    x.fillStyle = '#f6d7c3'; ell(x, w / 2, h * 0.5, w * 0.46, h * 0.48); x.fill();
    x.fillStyle = 'rgba(255,120,140,.25)';
    ell(x, w * 0.24, h * 0.66, 30, 16); x.fill(); ell(x, w * 0.76, h * 0.66, 30, 16); x.fill();
  } },
  { name: 'Ojo izq. abierto', preset: 'eyeLOpen', w: 90, h: 70, cx: 428, cy: 548, draw: eyeOpen },
  { name: 'Ojo izq. cerrado', preset: 'eyeLClosed', w: 90, h: 70, cx: 428, cy: 548, draw: eyeClosed },
  { name: 'Ojo der. abierto', preset: 'eyeROpen', w: 90, h: 70, cx: 572, cy: 548, draw: eyeOpen },
  { name: 'Ojo der. cerrado', preset: 'eyeRClosed', w: 90, h: 70, cx: 572, cy: 548, draw: eyeClosed },
  { name: 'Pupila izq.', preset: 'pupilL', w: 40, h: 40, cx: 428, cy: 548, draw: pupil },
  { name: 'Pupila der.', preset: 'pupilR', w: 40, h: 40, cx: 572, cy: 548, draw: pupil },
  { name: 'Ceja izq.', preset: 'browL', w: 90, h: 24, cx: 428, cy: 480, draw: brow },
  { name: 'Ceja der.', preset: 'browR', w: 90, h: 24, cx: 572, cy: 480, draw: brow },
  { name: 'Boca cerrada', preset: 'mouthClosed', w: 100, h: 50, cx: 500, cy: 650, draw(x, w, h) {
    x.strokeStyle = '#a2475a'; x.lineWidth = 7; x.lineCap = 'round';
    x.beginPath(); x.moveTo(10, 14); x.quadraticCurveTo(w / 2, h - 2, w - 10, 14); x.stroke();
  } },
  { name: 'Boca abierta', preset: 'mouthOpen', w: 100, h: 90, cx: 500, cy: 665, draw(x, w, h) {
    x.fillStyle = '#7a2a3d'; ell(x, w / 2, h / 2, w * 0.4, h * 0.42); x.fill();
    x.fillStyle = '#ff8fa3'; ell(x, w / 2, h * 0.72, w * 0.24, h * 0.16); x.fill();
  } },
  { name: 'Pelo delantero', preset: 'hairFront', w: 440, h: 190, cx: 500, cy: 450, draw(x, w, h) {
    x.fillStyle = '#6d4cb8';
    x.beginPath(); x.moveTo(0, h * 0.85);
    x.quadraticCurveTo(w * 0.02, 0, w * 0.5, h * 0.02);
    x.quadraticCurveTo(w * 0.98, 0, w, h * 0.85);
    x.quadraticCurveTo(w * 0.85, h * 0.35, w * 0.62, h * 0.55);
    x.quadraticCurveTo(w * 0.5, h * 0.95, w * 0.38, h * 0.55);
    x.quadraticCurveTo(w * 0.15, h * 0.35, 0, h * 0.85); x.fill();
  } },
];

function eyeOpen(x, w, h) {
  x.fillStyle = '#fff'; ell(x, w / 2, h / 2, w * 0.46, h * 0.44); x.fill();
  x.strokeStyle = '#2a2236'; x.lineWidth = 5; x.stroke();
}
function eyeClosed(x, w, h) {
  x.strokeStyle = '#2a2236'; x.lineWidth = 7; x.lineCap = 'round';
  x.beginPath(); x.moveTo(8, h / 2); x.quadraticCurveTo(w / 2, h * 0.8, w - 8, h / 2); x.stroke();
}
function pupil(x, w, h) {
  x.fillStyle = '#3b2a6b'; ell(x, w / 2, h / 2, w * 0.46, h * 0.46); x.fill();
  x.fillStyle = '#fff'; ell(x, w * 0.62, h * 0.35, 5, 5); x.fill();
}
function brow(x, w, h) {
  x.strokeStyle = '#4a3278'; x.lineWidth = 9; x.lineCap = 'round';
  x.beginPath(); x.moveTo(10, h * 0.7); x.quadraticCurveTo(w / 2, 0, w - 10, h * 0.7); x.stroke();
}

// Devuelve [{ name, preset, src, w, h, cx, cy, pivot }]
export function buildDemoSpecs() {
  return DEMO.map((d) => {
    const c = document.createElement('canvas');
    c.width = d.w; c.height = d.h;
    d.draw(c.getContext('2d'), d.w, d.h);
    return { name: d.name, preset: d.preset, src: c.toDataURL('image/png'), w: d.w, h: d.h, cx: d.cx, cy: d.cy, pivot: d.pivot || NECK };
  });
}
