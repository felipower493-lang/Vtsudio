// Seguimiento facial con MediaPipe Face Landmarker (se ejecuta en el teléfono, sin internet).
import { matrixToEuler } from './core.js';

let landmarker = null;

export const isReady = () => !!landmarker;

export async function initTracker() {
  if (landmarker) return;
  let vision;
  try {
    vision = await import('../vendor/vision_bundle.mjs');
  } catch (e) {
    throw new Error('Faltan los archivos de MediaPipe (ejecuta "npm run prepare:web" antes de compilar).');
  }
  const fileset = await vision.FilesetResolver.forVisionTasks('./vendor/wasm');
  const make = (delegate) =>
    vision.FaceLandmarker.createFromOptions(fileset, {
      baseOptions: { modelAssetPath: './vendor/face_landmarker.task', delegate },
      runningMode: 'VIDEO',
      numFaces: 1,
      outputFaceBlendshapes: true,
      outputFacialTransformationMatrixes: true,
    });
  try {
    landmarker = await make('GPU');
  } catch (e) {
    console.warn('GPU no disponible, usando CPU', e);
    landmarker = await make('CPU');
  }
}

// Devuelve { euler, bs, nose } o null si no hay cara.
export function detect(video, ts) {
  if (!landmarker) return null;
  const r = landmarker.detectForVideo(video, ts);
  if (!r.faceLandmarks || !r.faceLandmarks.length) return null;
  const bs = {};
  const cats = r.faceBlendshapes?.[0]?.categories || [];
  for (const k of cats) bs[k.categoryName] = k.score;
  const mat = r.facialTransformationMatrixes?.[0]?.data;
  if (!mat) return null;
  const nose = r.faceLandmarks[0][1];
  return { euler: matrixToEuler(mat), bs, nose: { x: nose.x, y: nose.y } };
}
